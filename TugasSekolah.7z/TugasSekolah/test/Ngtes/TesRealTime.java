package Ngtes;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import tugassekolah.ApotekUserForm;

    public class TesRealTime extends javax.swing.JFrame {
         private boolean databaru;
         private final Koneksi koneksi = new Koneksi();
   
         ResultSet rs;
         
    public TesRealTime() {
        initComponents();
        Tampil_Jam();
        Tampil_Tanggal();
    }

    private void getData() {
        try {
            Connection conn = koneksi.getKoneksi();
            Statement stm = conn.createStatement();
            ResultSet result = stm.executeQuery("SELECT * FROM tbl_log");
            
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            
            model.setRowCount(0);
            
            while (result.next()) {
            
            String id = result.getString("Id_Log");
            String waktu  = result.getString("waktu");
            String aktif = result.getString("aktifitas");
            String pengg = result.getString("Id_User");
            
            
            
            model.addRow(new Object[]{id, waktu, aktif, pengg});
            
        }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ApotekUserForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Tampil_Jam() {
        ActionListener taskPerformer = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                String nol_jam = "", nol_menit = "", nol_detik = "";
                
                java.util.Date dateTime = new java.util.Date();
                int nilai_jam = dateTime.getHours();
                int nilai_menit = dateTime.getMinutes();
                int nilai_detik = dateTime.getSeconds();
                
                if (nilai_jam <=9) nol_jam = "0";
                if (nilai_menit <=9) nol_menit = "0";
                if (nilai_detik <=9) nol_detik = "0";
                
                String jam = nol_jam + Integer.toString(nilai_jam);
                String menit = nol_menit + Integer.toString(nilai_menit);
                String detik = nol_detik + Integer.toString(nilai_detik);
                
                
            }
        };
        new Timer(1000, taskPerformer).start();
    }
    
    public void Tampil_Tanggal() {
        java.util.Date tglSekarang = new java.util.Date();
        SimpleDateFormat Format = new SimpleDateFormat("dd MMMM YYYY", Locale.getDefault());
        String tanggal = Format.format(tglSekarang);
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jButton1.setText("Pencet");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 220, 80));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pengguna", "Tanggal", "Waktu"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (databaru) {
            try {
                String sql = "INSERT Id_User FROM tbl_user Where Username ";
                
                sql = String.format (
                        sql
                );
                
                Connection conn = koneksi.getKoneksi();
                PreparedStatement pst = conn.prepareStatement(sql);
                
                pst.execute();
                
                JOptionPane.showMessageDialog(null, " Berhasil di simpan ");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, " Gagal di simpan " + ex);
            }
        } else{
               try {
                String sql = "UPDATE tbl_user SET Nama_User='%s', Tipe_User='%s',  Alamat='%s',  Telepon='%s' WHERE Id_User='%s'";
                
                sql = String.format (
                        sql
                );
                
                Connection conn = koneksi.getKoneksi();
                PreparedStatement pst = conn.prepareStatement(sql);
                
                pst.execute();
                
                JOptionPane.showMessageDialog(null, " Berhasil di edit ");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, " Gagal di edit " + ex);
            }
            
        }
        getData();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TesRealTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TesRealTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TesRealTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TesRealTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TesRealTime().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
