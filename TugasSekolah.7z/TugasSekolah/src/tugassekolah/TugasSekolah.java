package tugassekolah;

public class TugasSekolah {

    
    public static void main(String[] args) {
        System.out.print("                                               ");
        System.out.println("Program Aritmatika");
    }
    
}
